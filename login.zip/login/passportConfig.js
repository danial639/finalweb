require('dotenv').config(); // Подключаем dotenv для использования переменных окружения
const { Pool } = require('pg');
const bcrypt = require('bcrypt');
const speakeasy = require('speakeasy');
const twilio = require('twilio');
const LocalStrategy = require('passport-local').Strategy;

// Настройка подключения к базе данных с использованием переменных окружения
const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_DATABASE,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
});

// Настройка клиента Twilio
const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);

// Функция отправки 2FA кода через Twilio
async function sendVerificationCode(phoneNumber, token) {
    try {
        await client.messages.create({
            body: `Your 2FA code is: ${token}`,
            from: process.env.TWILIO_PHONE_NUMBER,
            to: phoneNumber,
        });
        console.log('Verification code sent successfully');
    } catch (err) {
        console.error('Error sending 2FA code:', err);
    }
}

// Инициализация Passport
function initialize(passport) {
    passport.use(
        new LocalStrategy(
          {
            usernameField: 'email',
            passwordField: 'password',
          },
          async (email, password, done) => {
            try {
              // Запрос к базе данных для получения пользователя по email
              const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
      
              if (result.rows.length === 0) {
                return done(null, false, { message: 'User not found' });
              }
      
              const user = result.rows[0];
      
              // Сравнение пароля (если используется bcrypt для хэширования)
              const isMatch = await bcrypt.compare(password, user.password);
              if (!isMatch) {
                return done(null, false, { message: 'Invalid credentials' });
              }
      
              // Если двухфакторная аутентификация включена
              if (user.twofa_enabled) {
                // Генерация и отправка кода 2FA
                const token = speakeasy.totp({
                  secret: user.secret,
                  encoding: 'base32',
                });
      
                // Отправка кода на телефон через Twilio
                await sendVerificationCode(user.phone, token);
      
                return done(null, user, { message: 'Please enter the 2FA code' });
              }
      
              // Если 2FA не включена, сразу аутентифицируем пользователя
              return done(null, user);
            } catch (err) {
              return done(err);
            }
          }
        )
    );

    passport.serializeUser((user, done) => {
        console.log("User serialized:", user.id);
        done(null, user.id);  // Сохраняем только ID пользователя в сессии
    });

    passport.deserializeUser(async (id, done) => {
      try {
        // Проверяем, есть ли пользователь в сессии
        if (!id) return done(null, false);
    
        // Проверяем, был ли пользователь ранее сериализован
        if (typeof id === 'object' && id.id) {
          return done(null, id); // Если уже есть пользователь в сессии, просто возвращаем его
        }
    
        // Если пользователя в сессии нет, получаем данные из базы
        const result = await pool.query("SELECT * FROM users WHERE id = $1", [id]);
        if (result.rows.length === 0) return done(null, false);
    
        const user = result.rows[0];
        done(null, user);
      } catch (err) {
        done(err, false);
      }
    });
}

module.exports = initialize;