require('dotenv').config(); // Подключаем dotenv для использования переменных окружения
const twilio = require('twilio');

// Получаем учетные данные из переменных окружения
const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const verifyServiceSid = process.env.TWILIO_VERIFY_SERVICE_SID;

const client = twilio(accountSid, authToken);

// Функция отправки кода подтверждения
function sendVerificationCode(phoneNumber) {
    client.verify.v2.services(verifyServiceSid)
        .verifications
        .create({to: phoneNumber, channel: 'sms'})
        .then(verification => {
            console.log(`Verification SID: ${verification.sid}`);
        })
        .catch(err => {
            console.error('Error sending verification code:', err);
        });
}


