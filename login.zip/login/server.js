require("dotenv").config();
const express = require("express");
const app = express();
const bcrypt = require("bcryptjs");
const session = require("express-session");
const flash = require("express-flash");
const passport = require("passport");
const initialize = require("./passportConfig");
const speakeasy = require("speakeasy");
const twilio = require("twilio");
const { Pool } = require("pg");
const bodyParser = require("body-parser");
const mongoose = require('mongoose');
const path = require('path');

mongoose.connect('mongodb://localhost:27017/football', {})
  .then(() => {
    console.log("Database connected successfully");
  })
  .catch((error) => {
    console.error("Database connection error:", error);
  });

app.use(express.static(path.join(__dirname, 'public')));

const playerSchema = new mongoose.Schema({
  Name: String,
  Age: Number,
  Nationality: String,
  Club: String,
  Value: Number,
  Wage: Number,
  Position: String,
  Skills: {
    Crossing: Number,
    Finishing: Number,
    HeadingAccuracy: Number,
    ShortPassing: Number,
    Volleys: Number,
    Dribbling: Number,
    Curve: Number,
    FKAccuracy: Number,
    LongPassing: Number,
    BallControl: Number,
    Acceleration: Number,
    SprintSpeed: Number,
    Agility: Number,
    Reactions: Number,
    Balance: Number,
    ShotPower: Number,
    Jumping: Number,
    Stamina: Number,
    Strength: Number,
    LongShots: Number,
    Aggression: Number,
    Interceptions: Number,
    Positioning: Number,
    Vision: Number,
    Penalties: Number,
    Composure: Number,
    Marking: Number,
    StandingTackle: Number,
    SlidingTackle: Number,
    GKDiving: Number,
    GKHandling: Number,
    GKKicking: Number,
    GKPositioning: Number,
    GKReflexes: Number
  }
});

const Player = mongoose.model('Player', playerSchema);

app.get('/analyticplatform', (req, res) => {
  res.render('analyticplatform');
});

app.get('/football/players', async (req, res) => {
  const { position, club, nationality, minAge, maxAge } = req.query;
  const filter = {};
  if (position) filter.Position = position;
  if (club) filter.Club = club;
  if (nationality) filter.Nationality = nationality;
  if (minAge) filter.Age = { $gte: Number(minAge) };
  if (maxAge) filter.Age = { ...filter.Age, $lte: Number(maxAge) };

  try {
    const players = await Player.find(filter);
    res.json(players);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching players' });
  }
});

app.get('/football/players/skills', async (req, res) => {
  const { skills } = req.query;
  const skillFields = skills ? skills.split(',') : [];
  const projection = {};
  skillFields.forEach(skill => projection[skill] = 1);

  try {
    const players = await Player.find({}, projection);
    res.json(players);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching skill data' });
  }
});

app.get('/football/players/statistics', async (req, res) => {
  const { field, position, club, nationality, minAge, maxAge } = req.query;

  try {
    const matchCriteria = {};
    if (position) matchCriteria.Position = position; 
    if (club) matchCriteria.Club = club; 
    if (nationality) matchCriteria.Nationality = nationality; 
    if (minAge) matchCriteria.Age = { $gte: Number(minAge) }; 
    if (maxAge) matchCriteria.Age = { ...matchCriteria.Age, $lte: Number(maxAge) };

    const stats = await Player.aggregate([
      { $match: matchCriteria }, 
      {
        $group: {
          _id: null,
          average: { $avg: `$${field}` },
          max: { $max: `$${field}` },
          min: { $min: `$${field}` },
          stdDev: { $stdDevPop: `$${field}` } 
        }
      }
    ]);
    res.json(stats[0] || { average: 0, max: 0, min: 0, stdDev: 0 });
  } catch (error) {
    res.status(500).json({ error: 'Error calculating statistics' });
  }
});

app.get('/football/players/:playerName', async (req, res) => {
  try {
    const playerName = req.params.playerName;
    const player = await Player.findOne({ Name: playerName });

    if (!player) {
      return res.status(404).json({ message: 'Player not found' });
    }

    res.json(player);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.get('/football/positions', async (req, res) => {
  const positions = await Player.distinct("Position");
  res.json(positions);
});

app.get('/football/clubs', async (req, res) => {
  const clubs = await Player.distinct("Club");
  res.json(clubs);
});

app.get('/football/nationalities', async (req, res) => {
  const nationalities = await Player.distinct("Nationality");
  res.json(nationalities);
});

app.get('/football/players/distribution/clubs', async (req, res) => {
  try {
    const clubsDistribution = await Player.aggregate([
      { $group: { _id: "$Club", count: { $sum: 1 } } }
    ]);
    res.json(clubsDistribution);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching clubs distribution data' });
  }
});

app.get('/football/players/distribution/nationalities', async (req, res) => {
  try {
    const nationalitiesDistribution = await Player.aggregate([
      { $group: { _id: "$Nationality", count: { $sum: 1 } } }
    ]);
    res.json(nationalitiesDistribution);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching nationalities distribution data' });
  }
});

app.get('/football/players/distribution/positions', async (req, res) => {
  try {
    const positionsDistribution = await Player.aggregate([
      { $group: { _id: "$Position", count: { $sum: 1 } } }
    ]);
    res.json(positionsDistribution);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching positions distribution data' });
  }
});
// Конфигурация базы данных
const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_DATABASE,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
});

// Инициализация Passport
initialize(passport);

// Инициализация Twilio
const client = twilio(process.env.TWILIO_SID, process.env.TWILIO_AUTH_TOKEN);
const PORT = process.env.PORT || 3000;

// Настройка Express
app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: false }));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Настройка сессий
app.use(
  session({
    secret: process.env.SESSION_SECRET || "defaultsecret",
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false }, // Убедитесь, что secure=true для HTTPS
  })
);

app.use(passport.initialize());
app.use(passport.session());
app.use(flash());

// Middleware для проверки аутентификации
function checkAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return res.redirect("/users/dashboard");
  }
  next();
}

function checkNoAuthenticated(req, res, next) {
  if (!req.isAuthenticated()) {
    req.flash("error_msg", "Please log in to access this page.");
    return res.redirect("/users/login");
  }
  next();
}

// Роуты
app.get("/", (req, res) => res.render("index"));

// Регистрация
app.get("/users/register", checkAuthenticated, (req, res) => res.render("register"));

// Логин
app.get("/users/login", checkAuthenticated, (req, res) => {
  res.render("login", { twofaRequired: req.session.twofaRequired && !req.session.twofaVerified });
});

app.get('/', (req, res) => {
  res.render('index'); // рендерим файл index.ejs
});

// Личный кабинет
app.get("/users/dashboard", checkNoAuthenticated, (req, res) => {
  res.render("dashboard", { user: req.user.name });
});

// Выход
app.get("/users/logout", (req, res, next) => {
  req.logout((err) => {
    if (err) return next(err);
    req.flash("success_msg", "You have logged out.");
    res.redirect("/users/login");
  });
});

// Регистрация пользователя
app.post("/users/register", async (req, res) => {
  const { name, lastname, age, gender, email, password, password2, phone } = req.body;
  const errors = [];

  if (!name || !lastname || !age || !gender || !email || !password || !password2 || !phone) {
    errors.push({ message: "Please enter all fields" });
  }

  if (password.length < 6) errors.push({ message: "Password should be at least 6 characters" });
  if (password !== password2) errors.push({ message: "Passwords do not match" });

  if (errors.length > 0) return res.render("register", { errors });

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const existingUser = await pool.query("SELECT * FROM users WHERE email = $1", [email]);

    if (existingUser.rows.length > 0) {
      errors.push({ message: "Email already registered" });
      return res.render("register", { errors });
    }

    const secret = speakeasy.generateSecret({ length: 20 });
    const code = speakeasy.totp({ secret: secret.base32, encoding: "base32" });

    await pool.query(
      `INSERT INTO users (name, lastname, age, gender, email, password, phone, secret, twofa_enabled, twofa_code)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
      [name, lastname, age, gender, email, hashedPassword, phone, secret.base32, true, code]
    );

    await client.messages.create({
      body: `Your 2FA code is: ${code}`,
      from: process.env.TWILIO_PHONE_NUMBER,
      to: phone,
    });

    req.flash("success_msg", "You are now registered. Check your phone for the 2FA code.");
    res.redirect("/users/login");
  } catch (err) {
    console.error(err);
    res.render("register", { errors: [{ message: "Something went wrong" }] });
  }
});

// Ввод 2FA кода
app.get("/users/verify-2fa", (req, res) => {
  if (!req.session.twofaRequired) return res.redirect("/users/login");
  res.render("verify-phone", { email: req.query.email || "" });
});

// Проверка 2FA кода
app.post("/users/verify-2fa", async (req, res) => {
  const { code } = req.body;

  try {
    const userRecord = await pool.query("SELECT secret FROM users WHERE email = $1", [req.user.email]);

    if (userRecord.rows.length === 0) {
      req.flash("error_msg", "User not found.");
      return res.redirect("/users/login");
    }

    const isValid = speakeasy.totp.verify({
      secret: userRecord.rows[0].secret,
      encoding: "base32",
      token: code,
    });

    if (!isValid) {
      req.flash("error_msg", "Invalid 2FA code. Please try again.");
      return res.redirect("/users/verify-2fa");
    }

    req.session.twofaVerified = true;
    req.flash("success_msg", "2FA verification successful.");
    res.redirect("/users/dashboard");
  } catch (err) {
    console.error(err);
    res.redirect("/users/login");
  }
});

// Логин пользователя
app.post("/users/login", (req, res, next) => {
  const { email, password } = req.body;

  passport.authenticate("local", async (err, user, info) => {
    if (err) return next(err);
    if (!user) {
      req.flash("error_msg", info.message);
      return res.redirect("/users/login");
    }

    req.logIn(user, async (err) => {
      if (err) return next(err);

      const userRecord = await pool.query("SELECT secret, twofa_enabled FROM users WHERE email = $1", [email]);

      if (userRecord.rows.length > 0) {
        req.user.secret = userRecord.rows[0].secret;
        req.user.twofa_enabled = userRecord.rows[0].twofa_enabled;
      }

      // Проверьте, включена ли 2FA
      if (user.twofa_enabled && !req.session.twofaVerified) {
        req.session.twofaRequired = true;
        return res.redirect("/users/verify-2fa"); // Перенаправить на страницу 2FA
      }

      // Если 2FA не требуется или уже подтверждена, сразу редирект на Dashboard
      req.flash("success_msg", "Login successful.");
      return res.redirect("/users/dashboard");
    });
  })(req, res, next);
});

app.get('/news', async (req, res) => {
  try {
      // Получаем новости из первого API
      const response1 = await fetch('https://newsapi.org/v2/top-headlines?country=us&apiKey=98d29ad3cb9440978475c0cb0a9d36de');
      const data1 = await response1.json();

      // Передаем полученные новости в шаблон EJS
      res.render('news', { news: data1.articles });
  } catch (error) {
      console.error('Ошибка при получении новостей:', error);
      res.status(500).send('Ошибка при загрузке новостей');
  }
});

const fetch = require('node-fetch'); // Подключаем fetch для выполнения HTTP-запросов

// API ключ для Football-Data.org
const API_KEY = 'e7158cbe635b46738bb6e6c8f5a47810';

app.get('/football', async (req, res) => {
    try {
        // Получаем информацию о турнире, например, о лигах
        const response = await fetch('https://api.football-data.org/v4/competitions', {
            headers: {
                'X-Auth-Token': API_KEY
            }
        });

        const data = await response.json();
        res.render('football', { competitions: data.competitions }); // Рендерим данные в EJS-шаблон
    } catch (error) {
        console.error('Ошибка при получении данных о футболе:', error);
        res.status(500).send('Ошибка при загрузке данных о футболе');
    }
});

app.get('/football/matches/:competitionId', async (req, res) => {
  const competitionId = req.params.competitionId; // Получаем ID турнира из URL
  try {
      // Получаем информацию о матчах турнира
      const response = await fetch(`https://api.football-data.org/v4/competitions/${competitionId}/matches`, {
          headers: {
              'X-Auth-Token': API_KEY
          }
      });

      const data = await response.json();
      res.render('matches', { matches: data.matches });
  } catch (error) {
      console.error('Ошибка при получении матчей:', error);
      res.status(500).send('Ошибка при загрузке матчей');
  }
});




app.use((req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');  // Отключает кэширование
  next();
});

// Запуск сервера
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
