document.addEventListener('DOMContentLoaded', async () => {
    await populateSelect('/football/positions', 'position');
    await populateSelect('/football/clubs', 'club');
    await populateSelect('/football/nationalities', 'nationality');
    await populatePlayers();
    await createCharts(); 
});

document.getElementById('filter-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const position = document.getElementById('position').value || undefined;
    const club = document.getElementById('club').value || undefined;
    const nationality = document.getElementById('nationality').value || undefined;
    const minAge = document.getElementById('minAge').value || undefined;
    const maxAge = document.getElementById('maxAge').value || undefined;
    const skills = document.getElementById('skills').value;

    const params = new URLSearchParams();
    if (position) params.append('position', position);
    if (club) params.append('club', club);
    if (nationality) params.append('nationality', nationality);
    if (minAge) params.append('minAge', minAge);
    if (maxAge) params.append('maxAge', maxAge);

    const response = await fetch(`/football/players?${params.toString()}`);
    
    if (!response.ok) {
        console.error('Ошибка при получении данных:', response.statusText);
        return;
    }
    
    const players = await response.json();

    const errorMessage = document.getElementById('error-message');
    if (players.length === 0) {
        errorMessage.style.display = 'block';
        return;
    } else {
        errorMessage.style.display = 'none'; 
    }

    
    const statsResponse = await fetch(`/football/players/statistics?field=${skills}&${params.toString()}`);
    const stats = await statsResponse.json();

   
    document.getElementById('avg-value').textContent = stats.average || 'N/A';
    document.getElementById('max-value').textContent = stats.max || 'N/A';
    document.getElementById('min-value').textContent = stats.min || 'N/A';
    document.getElementById('stddev-value').textContent = stats.stdDev || 'N/A';

    const labels = players.map(player => player.Name);
    const data = players.map(player => player[skills]);

    if (data.length === 0) {
        console.error('Нет данных для выбранного навыка');
        return;
    }

    if (window.chartInstance) {
        window.chartInstance.destroy();
    }

    
    window.chartInstance = new Chart(document.getElementById('chart'), {
        type: 'bar',
        data: {
            labels,
            datasets: [{
                label: `Навык: ${skills}`,
                data,
                backgroundColor: 'rgba(54, 52, 53, 1)',
            }]
        }
    });
});

document.getElementById('reset-button').addEventListener('click', () => {
    
    document.getElementById('filter-form').reset();

    
    document.getElementById('avg-value').textContent = '';
    document.getElementById('max-value').textContent = '';
    document.getElementById('min-value').textContent = '';
    document.getElementById('stddev-value').textContent = '';

   
    if (window.chartInstance) {
        window.chartInstance.destroy();
        window.chartInstance = null;
    }

    
    const chartContainer = document.getElementById('chart');
    chartContainer.innerHTML = ''; 
});

let players = []; 


async function populatePlayers() {
    const response = await fetch('/football/players');
    players = await response.json();
}


async function populateSelect(endpoint, selectId) {
    const response = await fetch(endpoint);
    const options = await response.json();
    const select = document.getElementById(selectId);
    options.forEach(option => {
        const opt = document.createElement('option');
        opt.value = option;
        opt.textContent = option;
        select.appendChild(opt);
    });
}


function showPlayerSuggestions(input) {
    const suggestionsContainer = document.getElementById('player-suggestions');
    suggestionsContainer.innerHTML = ''; 
    const query = input.toLowerCase();

    
    const filteredPlayers = players.filter(player => player.Name.toLowerCase().includes(query));

    if (filteredPlayers.length > 0) {
        suggestionsContainer.style.display = 'block';
        filteredPlayers.forEach(player => {
            const suggestionItem = document.createElement('div');
            suggestionItem.textContent = player.Name;
            suggestionItem.style.cursor = 'pointer';
            suggestionItem.onclick = () => {
                document.getElementById('player-input').value = player.Name;
                suggestionsContainer.style.display = 'none'; 
            };
            suggestionsContainer.appendChild(suggestionItem);
        });
    } else {
        suggestionsContainer.style.display = 'none'; 
    }
}


document.getElementById('player-input').addEventListener('input', (e) => {
    const inputValue = e.target.value;
    showPlayerSuggestions(inputValue);
});


document.getElementById('show-radar').addEventListener('click', async () => {
    const playerName = document.getElementById('player-input').value;
    if (playerName) {
        await showRadarChart(playerName);
    } else {
        alert('Пожалуйста, введите имя игрока.');
    }
});


async function showRadarChart(playerName) {
    const response = await fetch(`/football/players/${playerName}`);
    const player = await response.json();

    const skills = [
        'Crossing', 'Finishing', 'Dribbling', 'BallControl', 
        'ShotPower', 'Acceleration', 'Strength', 'Stamina'
    ];

    const values = skills.map(skill => player[skill]);

    
    if (window.radarChartInstance) {
        window.radarChartInstance.destroy();
    }

   
    const ctx = document.getElementById('radar-chart').getContext('2d');
    window.radarChartInstance = new Chart(ctx, {
        type: 'radar',
        data: {
            labels: skills,
            datasets: [{
                label: player.Name,
                data: values,
                backgroundColor: 'rgba(54, 52, 53, 0.9)',
            }]
        },
        options: {
            scales: {
                r: {
                    beginAtZero: true,
                }
            }
        }
    });
}

async function fetchDistributionData(url) {
    const response = await fetch(url);
    const data = await response.json();
    console.log('Данные для графика:', data); 
    return data;
}

let clubsChartInstance, nationalitiesChartInstance, positionsChartInstance;

async function createPieChart(canvasId, dataUrl, title) {
    
    if (canvasId === 'clubsChart' && clubsChartInstance) {
        clubsChartInstance.destroy();
    } else if (canvasId === 'nationalitiesChart' && nationalitiesChartInstance) {
        nationalitiesChartInstance.destroy();
    } else if (canvasId === 'positionsChart' && positionsChartInstance) {
        positionsChartInstance.destroy();
    }

    const data = await fetchDistributionData(dataUrl);
    if (data.length === 0) {
        console.error('Нет данных для создания графика', title);
        return; 
    }

    const labels = data.map(item => item._id); 
    const counts = data.map(item => item.count); 

    const ctx = document.getElementById(canvasId).getContext('2d');
    const chartInstance = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: labels,
            datasets: [{
                data: counts,
                backgroundColor: ['rgba(255, 5, 134, 1)', 'rgba(187, 5, 255, 1)', 'rgba(5, 36, 255, 1)', 'rgba(21, 255, 5, 1)', 'rgba(255, 5, 5, 1)'],
                hoverBackgroundColor: ['rgba(255, 5, 134, 1)', 'rgba(187, 5, 255, 1)', 'rgba(5, 36, 255, 1)', 'rgba(21, 255, 5, 1)', 'rgba(255, 5, 5, 1)']
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: title
                }
            }
        }
    });

   
    if (canvasId === 'clubsChart') {
        clubsChartInstance = chartInstance;
    } else if (canvasId === 'nationalitiesChart') {
        nationalitiesChartInstance = chartInstance;
    } else if (canvasId === 'positionsChart') {
        positionsChartInstance = chartInstance;
    }
}

async function createCharts() {
    await createPieChart('clubsChart', '/football/players/distribution/clubs', 'Распределение по клубам');
    await createPieChart('nationalitiesChart', '/football/players/distribution/nationalities', 'Распределение по национальностям');
    await createPieChart('positionsChart', '/football/players/distribution/positions', 'Распределение по позициям');
}
